 // script.ts

// Function to toggle visibility of an element
function toggleVisibility(elementId: string): void {
    const element = document.getElementById(elementId);
    if (element) {
        // Toggle the display property between 'none' and 'block'
        element.style.display = element.style.display === 'none' ? 'block' : 'none';
    }
}

// Adding event listeners to buttons when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
    const toggleExperienceButton = document.getElementById('toggleExperienceButton');
    const toggleCertificationButton = document.getElementById('toggleCertificationButton');
    const toggleSkillsButton = document.getElementById('toggleSkillsButton');

    // Event listener for toggling Experience section
    if (toggleExperienceButton) {
        toggleExperienceButton.addEventListener('click', () => toggleVisibility('experienceSection'));
    }

    // Event listener for toggling Certification section
    if (toggleCertificationButton) {
        toggleCertificationButton.addEventListener('click', () => toggleVisibility('certificationSection'));
    }

    // Event listener for toggling Skills section
    if (toggleSkillsButton) {
        toggleSkillsButton.addEventListener('click', () => toggleVisibility('skillsSection'));
    }
});